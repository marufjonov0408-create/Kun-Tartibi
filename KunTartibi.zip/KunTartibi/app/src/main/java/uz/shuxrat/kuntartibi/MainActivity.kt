package uz.shuxrat.kuntartibi

import android.Manifest
import android.app.AlarmManager
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Calendar

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    private val photo = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { b ->
        if (b != null) {
            val o = ByteArrayOutputStream()
            b.compress(Bitmap.CompressFormat.JPEG, 85, o)
            val s = Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
            web.evaluateJavascript("onNativePhoto('data:image/jpeg;base64,$s')", null)
        }
    }
    private val notif = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        web.evaluateJavascript("render()", null)
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val col = if (night) 0xFF12161D.toInt() else 0xFFF7F5EF.toInt()
        window.statusBarColor = col
        window.navigationBarColor = col
        web = WebView(this)
        web.setBackgroundColor(col)
        setContentView(web)
        WindowCompat.getInsetsController(window, web).apply {
            isAppearanceLightStatusBars = !night
            isAppearanceLightNavigationBars = !night
        }
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = WebViewClient()
        web.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("render()", null)
    }

    inner class Bridge {
        @JavascriptInterface fun takePhoto() { runOnUiThread { photo.launch(null) } }

        @JavascriptInterface fun hasUsage(): Boolean {
            val a = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            return a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
        }
        @JavascriptInterface fun openUsage() { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }

        @JavascriptInterface fun hasNotif(): Boolean = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        @JavascriptInterface fun askNotif() {
            runOnUiThread { if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS) }
        }

        @JavascriptInterface fun hasExact(): Boolean = Build.VERSION.SDK_INT < 31 ||
            (getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
        @JavascriptInterface fun askExact() {
            if (Build.VERSION.SDK_INT >= 31)
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
        }

        @JavascriptInterface fun usage(): String {
            val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val c = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val home = packageManager.resolveActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName
            val list = um.queryAndAggregateUsageStats(c.timeInMillis, System.currentTimeMillis()).values
                .filter { it.totalTimeInForeground > 60000 && it.packageName != packageName && it.packageName != home &&
                    packageManager.getLaunchIntentForPackage(it.packageName) != null }
                .sortedByDescending { it.totalTimeInForeground }
            val apps = JSONArray()
            for (u in list.take(6)) {
                val n = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(u.packageName, 0)).toString() }
                        catch (e: Exception) { u.packageName }
                apps.put(JSONObject().put("n", n).put("m", (u.totalTimeInForeground / 60000).toInt()))
            }
            return JSONObject().put("total", (list.sumOf { it.totalTimeInForeground } / 60000).toInt()).put("apps", apps).toString()
        }

        @JavascriptInterface fun setReminders(json: String) {
            getSharedPreferences("r", 0).edit().putString("j", json).apply()
            Alarms.schedule(this@MainActivity)
        }
    }
}
