package uz.shuxrat.kuntartibi

import android.app.*
import android.content.*
import android.os.Build
import org.json.JSONArray
import java.util.Calendar

object Alarms {
    fun pi(c: Context, code: Int, text: String): PendingIntent = PendingIntent.getBroadcast(
        c, code, Intent(c, AlarmReceiver::class.java).putExtra("x", text).putExtra("id", code),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun schedule(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val arr = JSONArray(c.getSharedPreferences("r", 0).getString("j", "[]"))
        for (i in 0 until 30) am.cancel(pi(c, 100 + i, ""))
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        for (i in 0 until minOf(arr.length(), 30)) {
            val o = arr.getJSONObject(i)
            val t = o.getString("t").split(":")
            val da = o.getJSONArray("d")
            val days = (0 until da.length()).map { da.getInt(it) }
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, t[0].toInt()); set(Calendar.MINUTE, t[1].toInt())
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            var n = 0
            while (n < 8 && (cal.timeInMillis <= System.currentTimeMillis() || !days.contains(cal.get(Calendar.DAY_OF_WEEK) - 1))) {
                cal.add(Calendar.DAY_OF_YEAR, 1); n++
            }
            val p = pi(c, 100 + i, o.getString("x"))
            if (o.optInt("a") == 1) {
                val show = PendingIntent.getActivity(c, 1, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
                am.setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, show), p)
            } else if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, p)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, p)
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) { Alarms.schedule(c); return }
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("k", "Eslatmalar", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(i.getIntExtra("id", 0), Notification.Builder(c, "k").setSmallIcon(R.drawable.ic_fg)
            .setContentTitle("Kun tartibi").setContentText(i.getStringExtra("x")).setContentIntent(open).setAutoCancel(true).build())
        Alarms.schedule(c)
    }
}
